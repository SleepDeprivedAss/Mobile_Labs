import 'package:flutter/material.dart';
import 'dart:math';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Список элементов',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Степени числа 2'),
        ),
        body: ListView.builder(
          padding: EdgeInsets.all(5.0),
          itemExtent: 50.0,
          itemBuilder: (BuildContext context, int index) {
            num rez = pow(2, index);
            return Text(' 2^$index = $rez', style: TextStyle(fontSize: 14.0));
          },
        ),
      ),
    );
  }
}
